export const product = [{
    productId: 'P001',
    productImg: '../image/P001.jpg',
    productName: 'SHINE Drawstring Ruched Side Crop Tank Top',
    productDesc: 'Casual, Crop',
    productPrice: '130 Baht',
    productStock: '284 pieces'
}, {
    productId: 'P002',
    productImg: '../image/P002.jpg',
    productName: 'DAZY Plicated Detail Split Hem Tee Dress',
    productDesc: 'Elegant ,Midi ,Summer',
    productPrice: '310 Baht',
    productStock: '89 pieces'
}, {
    productId: 'P003',
    productImg: '../image/P003.jpg',
    productName: 'DAZY Patch Detail Keyhole Back Blouse',
    productDesc: 'Casual, Regular ,Spring/Fall',
    productPrice: '198 Baht',
    productStock: '94 pieces'
}, {
    productId: 'P004',
    productImg: '../image/P004.jpg',
    productName: 'DAZY Solid Ruched Crop Blouse',
    productDesc: 'Boho, Ruched, Crop',
    productPrice: '240 Baht',
    productStock: '58 pieces'

}, {
    productId: 'P005',
    productImg: '../image/P005.jpg',
    productName: 'DAZY Puff Sleeve Textured Blouse',
    productDesc: 'Casual ,Crop ,Spring/Fall',
    productPrice: '290 Baht',
    ProductStock: '70 pieces'

}, {
    productId: 'P006',
    productImg: '../image/P006.jpg',
    productName: 'DAZY Puff Sleeve Contrast Binding Blouse',
    productDesc: 'Casual, Crop,Summer',
    productPrice: '200 Baht',
    productStock: '99 pieces'
}, {
    productId: 'P007',
    productImg: '../image/P007.jpg',
    productName: 'DAZY Flap Detail Crop Blouse',
    productDesc: 'Casual ,Crop ,Summer',
    productPrice: '209 Baht',
    productStock: '56 pieces'
}]